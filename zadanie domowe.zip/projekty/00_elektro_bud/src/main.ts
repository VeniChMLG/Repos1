/**
 * OPIS FUNKCJONALNOŚCI:
 * Aplikacja magazynowa dla Elektro-Bud realizuje:
 * - Wyświetlanie listy produktów w tabeli
 * - Dodawanie nowego produktu do magazynu
 * - Usuwanie produktu z magazynu
 * - Zapisywanie i odczytywanie stanu magazynu z localStorage (ocena 6)
 */

import { Produkt } from './types';

class MagazynApp {
    private produkty: Produkt[] = [];
    private storageKey = 'elektro_bud_magazyn';

    constructor() {
        this.wczytajZLocalStorage();
        this.inicjalizujInterfejs();
    }

    private wczytajZLocalStorage(): void {
        const dane = localStorage.getItem(this.storageKey);
        if (dane) {
            try {
                this.produkty = JSON.parse(dane);
            } catch (e) {
                console.error("Błąd parsowania danych z localStorage", e);
                this.produkty = [];
            }
        } else {
            // Domyślne dane, jeśli localStorage jest pusty
            this.produkty = [
                { id: 1, nazwa: 'Kabel YDYp 3x1.5', kategoria: 'Kable', ilosc: 100, cena: 3.50 },
                { id: 2, nazwa: 'Wyłącznik nadprądowy B16', kategoria: 'Aparatura', ilosc: 20, cena: 18.00 }
            ];
            this.zapiszDoLocalStorage();
        }
    }

    private zapiszDoLocalStorage(): void {
        localStorage.setItem(this.storageKey, JSON.stringify(this.produkty));
    }

    public dodajProdukt(nazwa: string, kategoria: string, ilosc: number, cena: number): void {
        const nowy: Produkt = {
            id: Date.now(),
            nazwa,
            kategoria,
            ilosc,
            cena
        };
        this.produkty.push(nowy);
        this.zapiszDoLocalStorage();
        this.odswiezWidok();
    }

    public usunProdukt(id: number): void {
        this.produkty = this.produkty.filter(p => p.id !== id);
        this.zapiszDoLocalStorage(); // <-- Poprawiona nazwa (zmienione "To" na "Do")
        this.odswiezWidok();
    }

    private odswiezWidok(): void {
        const tbody = document.querySelector('#tabela-produktow') as HTMLTableElement;
        if (!tbody) return;

        tbody.innerHTML = '';
        this.produkty.forEach(p => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${p.nazwa}</td>
                <td>${p.kategoria}</td>
                <td>${p.ilosc}</td>
                <td>${p.cena.toFixed(2)} zł</td>
                <td><button data-id="${p.id}" class="btn-usun">Usuń</button></td>
            `;
            tbody.appendChild(row);
        });

        // Podpięcie zdarzeń do przycisków usuwania
        document.querySelectorAll('.btn-usun').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = Number((e.currentTarget as HTMLElement).getAttribute('data-id'));
                this.usunProdukt(id);
            });
        });
    }

    public inicjalizujInterfejs(): void {
        this.odswiezWidok();

        const form = document.querySelector('#form-produkt') as HTMLFormElement;
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const nazwaInput = (document.querySelector('#nazwa') as HTMLInputElement).value;
                const kategoriaInput = (document.querySelector('#kategoria') as HTMLInputElement).value;
                const iloscInput = Number((document.querySelector('#ilosc') as HTMLInputElement).value);
                const cenaInput = Number((document.querySelector('#cena') as HTMLInputElement).value);

                this.dodajProdukt(nazwaInput, kategoriaInput, iloscInput, cenaInput);
                form.reset();
            });
        }
    }
}

// Uruchomienie aplikacji po załadowaniu strony
document.addEventListener('DOMContentLoaded', () => {
    new MagazynApp();
});