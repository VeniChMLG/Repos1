export interface Produkt {
    id: number;
    nazwa: string;
    kategoria: string;
    ilosc: number;
    cena: number;
}