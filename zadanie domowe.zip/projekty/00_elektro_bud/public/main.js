/**
 * OPIS FUNKCJONALNOŚCI:
 * Aplikacja magazynowa dla Elektro-Bud realizuje:
 * - Wyświetlanie listy produktów w tabeli
 * - Dodawanie nowego produktu do magazynu
 * - Usuwanie produktu z magazynu
 * - Zapisywanie i odczytywanie stanu magazynu z localStorage (ocena 6)
 */
class MagazynApp {
    produkty = [];
    storageKey = 'elektro_bud_magazyn';
    constructor() {
        this.wczytajZLocalStorage();
        this.inicjalizujInterfejs();
    }
    wczytajZLocalStorage() {
        const dane = localStorage.getItem(this.storageKey);
        if (dane) {
            try {
                this.produkty = JSON.parse(dane);
            }
            catch (e) {
                console.error("Błąd parsowania danych z localStorage", e);
                this.produkty = [];
            }
        }
        else {
            // Domyślne dane, jeśli localStorage jest pusty
            this.produkty = [
                { id: 1, nazwa: 'Kabel YDYp 3x1.5', kategoria: 'Kable', ilosc: 100, cena: 3.50 },
                { id: 2, nazwa: 'Wyłącznik nadprądowy B16', kategoria: 'Aparatura', ilosc: 20, cena: 18.00 }
            ];
            this.zapiszDoLocalStorage();
        }
    }
    zapiszDoLocalStorage() {
        localStorage.setItem(this.storageKey, JSON.stringify(this.produkty));
    }
    dodajProdukt(nazwa, kategoria, ilosc, cena) {
        const nowy = {
            id: Date.now(),
            nazwa,
            kategoria,
            ilosc,
            cena
        };
        this.produkty.push(nowy);
        this.zapiszDoLocalStorage();
        this.odswiezWidok();
    }
    usunProdukt(id) {
        this.produkty = this.produkty.filter(p => p.id !== id);
        this.zapiszDoLocalStorage(); // <-- Poprawiona nazwa (zmienione "To" na "Do")
        this.odswiezWidok();
    }
    odswiezWidok() {
        const tbody = document.querySelector('#tabela-produktow');
        if (!tbody)
            return;
        tbody.innerHTML = '';
        this.produkty.forEach(p => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${p.nazwa}</td>
                <td>${p.kategoria}</td>
                <td>${p.ilosc}</td>
                <td>${p.cena.toFixed(2)} zł</td>
                <td><button data-id="${p.id}" class="btn-usun">Usuń</button></td>
            `;
            tbody.appendChild(row);
        });
        // Podpięcie zdarzeń do przycisków usuwania
        document.querySelectorAll('.btn-usun').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = Number(e.currentTarget.getAttribute('data-id'));
                this.usunProdukt(id);
            });
        });
    }
    inicjalizujInterfejs() {
        this.odswiezWidok();
        const form = document.querySelector('#form-produkt');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const nazwaInput = document.querySelector('#nazwa').value;
                const kategoriaInput = document.querySelector('#kategoria').value;
                const iloscInput = Number(document.querySelector('#ilosc').value);
                const cenaInput = Number(document.querySelector('#cena').value);
                this.dodajProdukt(nazwaInput, kategoriaInput, iloscInput, cenaInput);
                form.reset();
            });
        }
    }
}
// Uruchomienie aplikacji po załadowaniu strony
document.addEventListener('DOMContentLoaded', () => {
    new MagazynApp();
});
export {};
